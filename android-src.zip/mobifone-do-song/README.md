# MobiFone Đo Sóng — app Android đọc thông số vô tuyến cho Web Bản đồ số

Ứng dụng **vỏ bọc mỏng** cho Web Bản đồ số MobiFone Hưng Yên. Giao diện vẫn là trang web hiện có,
app chỉ bổ sung đúng một thứ mà trình duyệt không bao giờ làm được: **đọc thông số sóng thật từ modem**.

Khi mở web bằng app này, nút **📶 Sóng hiện tại** trên bản đồ sẽ hiện đầy đủ:
Cell ID · PCI · TAC · Tần số (EARFCN / NR-ARFCN) · Band · Băng thông · Công nghệ ·
RSRP · RSRQ · SINR · Timing Advance · MCC/MNC · danh sách ô lân cận — tự làm mới mỗi 3 giây.

Mở bằng trình duyệt thường thì các trường này để trống và web nói rõ lý do (đây là chặn cứng
của nền tảng web, không phải lỗi).

---

## 1. Build ra file APK

**Cách nhanh nhất — dùng Android Studio (khuyến nghị):**

1. Cài **Android Studio** (bản Ladybug trở lên) tại https://developer.android.com/studio
2. `File → Open…` → chọn thư mục `mobifone-do-song`
3. Chờ Gradle sync xong (lần đầu mất 5–15 phút vì phải tải thư viện).
   *Nếu Studio hỏi về Gradle wrapper, chọn dùng Gradle bản đi kèm Android Studio.*
4. `Build → Build Bundle(s) / APK(s) → Build APK(s)`
5. File nằm tại `app/build/outputs/apk/debug/app-debug.apk`

**Bản dùng chính thức (ký để không bị cảnh báo khi cài):**

1. `Build → Generate Signed App Bundle / APK… → APK`
2. `Create new…` để tạo keystore — **giữ kỹ file keystore và mật khẩu**, mất là không cập nhật app được nữa
3. Chọn `release` → Finish → file ở `app/build/outputs/apk/release/`

---

## 2. Cài lên máy cán bộ hiện trường

Chép file APK vào máy rồi mở. Android sẽ hỏi cho phép **"Cài ứng dụng không rõ nguồn gốc"** —
đây là bình thường với app nội bộ không phát hành qua CH Play.

Nếu đơn vị có hệ thống **MDM / Android Enterprise** thì nên phát hành qua đó: cấp sẵn quyền Vị trí
từ xa, khoá công tắc Định vị ở trạng thái bật, cài im lặng — bỏ được gần hết thao tác thủ công.

---

## 3. Ba việc người dùng phải làm, nếu không sẽ không có số liệu

| Việc | Vì sao bắt buộc |
|---|---|
| Cấp quyền **Vị trí** và chọn mức **"Chính xác"** | Android bắt buộc quyền vị trí chính xác mới cho đọc thông tin ô phục vụ. Chọn mức "Gần đúng" thì hệ thống trả về danh sách rỗng. |
| **Bật công tắc Định vị** của máy | Khi tắt, `getAllCellInfo()` trả về danh sách rỗng **mà không báo lỗi gì** — app sẽ hiện cảnh báo nhắc bật. |
| Cập nhật **Android System WebView** và **Chrome** trong CH Play | Cầu nối dữ liệu dùng `WebViewCompat.addWebMessageListener`, bản WebView quá cũ sẽ không hỗ trợ. App sẽ báo nếu gặp trường hợp này. |

App **không** xin quyền vị trí nền — chỉ đo khi đang mở app.

---

## 4. Những gì máy có thể không trả về (không phải lỗi app)

- **Ô lân cận**: nhiều dòng **Samsung** từ Android 10 trở lên chỉ trả về ô đang phục vụ.
  App sẽ hiện cảnh báo, số liệu ô phục vụ vẫn chính xác.
- **Band / Băng thông**: chỉ có trên máy Android 11+ và tuỳ chipset. Băng thông chính xác nằm ở
  `PhysicalChannelConfig`, cần quyền cấp hệ thống mà app thường không có.
- **CQI, Timing Advance**: tuỳ chipset; Timing Advance chỉ có khi máy đang có kết nối dữ liệu tích cực.
- **5G NSA**: nhiều máy không đưa ô NR vào danh sách ô. App đã xử lý bằng cách gộp thêm nguồn
  `getSignalStrength()`, nên vẫn hiện được SS-RSRP/RSRQ/SINR của lớp 5G, kèm ghi chú
  "định danh ô là của ô neo 4G".

**iPhone: không có cách nào.** Apple chặn ở tầng hệ điều hành từ iOS 8.3, kể cả app phân phối
nội bộ qua Enterprise Program cũng không đọc được. Người dùng iPhone phải xem thủ công bằng
Field Test Mode (quay số `*3001#12345#*`) rồi nhập tay vào web.

---

## 5. Cấu trúc mã nguồn

```
app/src/main/java/vn/mobifone/hungyen/dosong/
├── MainActivity.kt   — vỏ WebView, xin quyền, hỏi modem theo chu kỳ 3 giây, cài cầu nối
└── RadioReader.kt    — đọc CellInfo + SignalStrength, đóng gói thành JSON cho web
```

Đổi địa chỉ web: sửa hằng `WEB_URL` và `ALLOWED_ORIGINS` trong `MainActivity.kt`.
**Phải sửa cả hai** — `ALLOWED_ORIGINS` là danh sách origin được phép gọi cầu nối.

### Vì sao dùng `addWebMessageListener` chứ không phải `addJavascriptInterface`

Trang web có nhúng iframe của bên thứ ba (bản tin, kết quả xổ số). `addJavascriptInterface`
tiêm đối tượng vào **mọi khung, kể cả iframe ngoài**, nghĩa là trang lạ cũng gọi được cầu nối.
`addWebMessageListener` có ràng buộc origin ngay ở tầng framework nên chỉ đúng địa chỉ web
của mình mới gọi được. Đừng đổi ngược lại.

### Hợp đồng dữ liệu với web

App trả về JSON qua cầu nối, web đọc ở hàm `renderLiveSignalNative()`:

```json
{
  "ok": true,
  "congNghe": "4G LTE",          
  "nhaMang": "MobiFone",
  "cellId": 41000607, "pci": 116, "tac": 41003,
  "tanSo": 1850, "band": "B3", "bangThongKhz": 20000,
  "rsrp": -87.0, "rsrq": -9.5, "sinr": 14.2,
  "timingAdvance": 3, "mcc": "452", "mnc": "01",
  "nrRsrp": null, "nrRsrq": null, "nrSinr": null,
  "lanCan": [{"pci":118,"tanSo":1850,"rsrp":-104,"rsrq":-14}],
  "thoiDiemMs": 1786000000000,
  "canhBao": null
}
```

Khi không đọc được: `{"ok": false, "canhBao": "<lý do bằng tiếng Việt>"}` — web sẽ hiện
nguyên câu cảnh báo đó cho người dùng, nên viết câu nào là người dùng đọc câu đó.

---

## 6. Nếu sau này muốn đưa lên Google Play

Cài APK nội bộ thì **không vướng** chính sách nào của Google Play. Nếu đưa lên Play thì cần:

- Bản công bố rõ ràng (prominent disclosure) trước khi xin quyền — app đã có sẵn hộp thoại giải thích.
- Khai báo mục Data safety.
- Chính sách **"Minimum Scope: Foreground Location Access and the Location Button"** áp dụng cho
  app nhắm Android 17 trở lên, dự kiến thực thi từ **cuối tháng 10/2026**. App đo sóng vẫn được
  xin quyền vị trí chính xác thường trực vì đó là chức năng cốt lõi, nhưng phải chuẩn bị hồ sơ
  giải trình trong Play Console.

---

*Nội bộ MobiFone Hưng Yên — NamNV (namnv.vn@gmail.com). Lập ngày 05/08/2026.*
