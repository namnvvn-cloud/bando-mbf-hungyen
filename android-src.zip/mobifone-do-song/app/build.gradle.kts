plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "vn.mobifone.hungyen.dosong"
    compileSdk = 35

    defaultConfig {
        applicationId = "vn.mobifone.hungyen.dosong"
        // minSdk 26 (Android 8.0): từ mức này mới có getRsrp()/getRsrq()/getRssnr() của LTE.
        // Máy cũ hơn vẫn cài được nhưng sẽ không đọc được mức thu -> không hỗ trợ.
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    /*  Ký bằng keystore CỐ ĐỊNH nằm trong repo (keystore/mbf-hyn.jks).
        Vì sao không dùng debug.keystore mặc định: mỗi máy build (kể cả máy ảo GitHub Actions)
        tự sinh một debug.keystore khác nhau -> mỗi lần build ra chữ ký khác -> người dùng phải
        GỠ app cũ mới cài được bản mới. Dùng key cố định thì cập nhật là đè thẳng lên, không mất
        dữ liệu, không phải gỡ.
        ⚠ Đây là key tự ký dùng cho phân phối nội bộ (sideload), KHÔNG phải key Google Play. */
    signingConfigs {
        create("noibo") {
            storeFile = rootProject.file("keystore/mbf-hyn.jks")
            storePassword = "mbfhyn2026"
            keyAlias = "mbfhyn"
            keyPassword = "mbfhyn2026"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("noibo")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug {
            signingConfig = signingConfigs.getByName("noibo")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.13.1")
    // Bắt buộc: WebViewCompat.addWebMessageListener (cầu nối có ràng buộc origin)
    implementation("androidx.webkit:webkit:1.12.1")
}
