package vn.mobifone.hungyen.dosong

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telephony.CellInfo
import android.telephony.TelephonyManager
import android.webkit.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import java.util.concurrent.Executors

/**
 * Vỏ bọc mỏng cho Web Bản đồ số MobiFone Hưng Yên.
 *
 * Toàn bộ giao diện vẫn là trang web hiện có — app này chỉ làm đúng 3 việc:
 *   1. Xin quyền Vị trí chính xác (Android bắt buộc mới cho đọc thông tin ô phục vụ).
 *   2. Hỏi modem lấy thông số vô tuyến theo chu kỳ (tôn trọng giới hạn ~2 giây của modem).
 *   3. Mở một cầu nối để trang web gọi sang lấy số liệu.
 *
 * BẢO MẬT — vì sao dùng addWebMessageListener chứ không phải addJavascriptInterface:
 * trang web có nhúng iframe của bên thứ ba (bản tin, kết quả xổ số). addJavascriptInterface
 * tiêm đối tượng vào MỌI khung, kể cả iframe ngoài, nên trang lạ cũng gọi được.
 * addWebMessageListener có ràng buộc origin ngay ở tầng framework -> chỉ đúng địa chỉ
 * web của mình mới gọi được.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        /** Đổi thành địa chỉ web nội bộ nếu sau này chuyển hosting. */
        const val WEB_URL = "https://namnvvn-cloud.github.io/bando-mbf-hungyen/"
        private val ALLOWED_ORIGINS = setOf("https://namnvvn-cloud.github.io")
        private const val BRIDGE_NAME = "MBFSignalBridge"
        /** Modem Android chỉ phục vụ tối đa ~1 lần/2000 ms; hỏi dày hơn chỉ tốn pin mà vẫn nhận lại cache cũ. */
        private const val POLL_MS = 3000L
    }

    private lateinit var web: WebView
    private var tm: TelephonyManager? = null
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    @Volatile private var latestCells: List<CellInfo>? = null
    private var polling = false

    private val askPerms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        val fine = res[Manifest.permission.ACCESS_FINE_LOCATION] == true
        if (!fine) {
            Toast.makeText(
                this,
                "Chưa có quyền Vị trí chính xác — app sẽ không đọc được Cell ID/RSRP. Bản đồ vẫn dùng bình thường.",
                Toast.LENGTH_LONG
            ).show()
        }
        startPolling()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tm = getSystemService(TELEPHONY_SERVICE) as? TelephonyManager

        web = WebView(this)
        setContentView(web)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true          // web dùng localStorage để nhớ đăng nhập
            loadWithOverviewMode = true
            useWideViewPort = true
            setGeolocationEnabled(true)
            // Siết các đường truy cập không cần thiết
            allowFileAccess = false
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false
            mediaPlaybackRequiresUserGesture = true
        }
        WebView.setWebContentsDebuggingEnabled(false)

        web.webChromeClient = object : WebChromeClient() {
            // Trang web gọi navigator.geolocation -> cho phép nếu app đã có quyền hệ thống
            override fun onGeolocationPermissionsShowPrompt(origin: String?, cb: GeolocationPermissions.Callback?) {
                val ok = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) ==
                    PackageManager.PERMISSION_GRANTED
                cb?.invoke(origin, ok, false)
            }
        }
        web.webViewClient = object : WebViewClient() {
            // Chỉ cho điều hướng trong phạm vi web của mình; link ngoài mở bằng trình duyệt hệ thống
            override fun shouldOverrideUrlLoading(v: WebView?, req: WebResourceRequest?): Boolean {
                val u = req?.url ?: return false
                val origin = "${u.scheme}://${u.host}"
                if (ALLOWED_ORIGINS.contains(origin)) return false
                return try {
                    startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, u)); true
                } catch (e: Exception) { true }
            }
        }

        installBridge()
        web.loadUrl(WEB_URL)

        requestNeededPermissions()
    }

    private fun requestNeededPermissions() {
        val need = mutableListOf<String>()
        // Android 12+ bắt buộc xin COARSE cùng lúc với FINE, nếu không hộp thoại sẽ không có lựa chọn "Chính xác"
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            need += Manifest.permission.ACCESS_COARSE_LOCATION
            need += Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            need += Manifest.permission.READ_PHONE_STATE
        }
        if (need.isEmpty()) { startPolling(); return }

        // Giải thích TRƯỚC khi hiện hộp thoại hệ thống, đúng thông lệ và yêu cầu của Google Play
        AlertDialog.Builder(this)
            .setTitle("Cần quyền Vị trí chính xác")
            .setMessage(
                "Ứng dụng đọc thông số sóng (Cell ID, tần số, RSRP, RSRQ, SINR) mà máy đang bắt, để phục vụ " +
                "công tác đo kiểm vùng phủ của MobiFone Hưng Yên.\n\n" +
                "Android bắt buộc quyền Vị trí ở mức CHÍNH XÁC mới cho phép đọc các thông số này — đây là quy định " +
                "của hệ điều hành, không phải app thu thập thêm dữ liệu.\n\n" +
                "Ở màn hình tiếp theo, vui lòng chọn \"Khi dùng ứng dụng\" và bật \"Chính xác\"."
            )
            .setPositiveButton("Tiếp tục") { _, _ -> askPerms.launch(need.toTypedArray()) }
            .setNegativeButton("Chỉ xem bản đồ") { _, _ -> startPolling() }
            .setCancelable(false)
            .show()
    }

    /** Cài cầu nối để trang web gọi sang. Ưu tiên WebMessageListener vì có ràng buộc origin. */
    private fun installBridge() {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            Toast.makeText(
                this,
                "Bản Android System WebView trên máy quá cũ nên không bật được chức năng đọc sóng. " +
                "Hãy cập nhật \"Android System WebView\" và \"Chrome\" trong CH Play rồi mở lại app.",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        WebViewCompat.addWebMessageListener(web, BRIDGE_NAME, ALLOWED_ORIGINS) { _, message, _, isMainFrame, replyProxy ->
            if (!isMainFrame) return@addWebMessageListener      // bỏ qua mọi lời gọi từ iframe
            val action = try { JSONObject(message.data ?: "{}").optString("action") } catch (e: Exception) { "" }
            if (action != "readSignal") return@addWebMessageListener
            val json = RadioReader.read(this, latestCells).put("__mbf", "signal")
            replyProxy.postMessage(json.toString())
        }
    }

    /**
     * Hỏi modem lấy dữ liệu TƯƠI theo chu kỳ.
     * Bẫy 3: app nhắm API 29+ gọi getAllCellInfo() chỉ nhận cache, nên phải dùng requestCellInfoUpdate().
     */
    private fun startPolling() {
        if (polling) return
        polling = true
        main.post(object : Runnable {
            override fun run() {
                requestFreshCells()
                if (polling) main.postDelayed(this, POLL_MS)
            }
        })
    }

    private fun requestFreshCells() {
        val t = tm ?: return
        if (!RadioReader.hasFineLocation(this) || !RadioReader.isLocationEnabled(this)) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                t.requestCellInfoUpdate(io, object : TelephonyManager.CellInfoCallback() {
                    override fun onCellInfo(cellInfo: MutableList<CellInfo>) { latestCells = cellInfo }
                    override fun onError(errorCode: Int, detail: Throwable?) {
                        // Bẫy 4: modem không trả lời trong 2 giây -> giữ lại số liệu lần trước, không làm treo giao diện
                    }
                })
            } else {
                @Suppress("DEPRECATION")
                latestCells = t.allCellInfo
            }
        } catch (e: SecurityException) {
            // quyền bị thu hồi giữa chừng — lần đọc kế tiếp sẽ báo lý do cho người dùng
        } catch (e: Exception) {
        }
    }

    override fun onResume() { super.onResume(); startPolling() }
    override fun onPause() { super.onPause(); polling = false; main.removeCallbacksAndMessages(null) }

    override fun onDestroy() {
        polling = false
        main.removeCallbacksAndMessages(null)
        io.shutdownNow()
        web.destroy()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
