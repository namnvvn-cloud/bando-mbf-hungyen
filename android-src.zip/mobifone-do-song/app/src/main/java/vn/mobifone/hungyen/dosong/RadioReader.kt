package vn.mobifone.hungyen.dosong

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import android.telephony.*
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

/**
 * Đọc thông số vô tuyến của ô đang phục vụ + ô lân cận, trả về JSON đúng "hợp đồng dữ liệu"
 * mà trang web Bản đồ số đang chờ (xem hàm renderLiveSignalNative trong web).
 *
 * SÁU CÁI BẪY ĐÃ ĐƯỢC XỬ LÝ Ở ĐÂY — đừng bỏ đi khi sửa lại:
 *
 *  1. Công tắc Location của hệ thống bị TẮT  -> getAllCellInfo() trả về danh sách RỖNG,
 *     không ném lỗi, không báo gì. Phải tự kiểm tra và nói rõ cho người dùng.
 *  2. Quyền chỉ ở mức "Approximate" (Android 12+) -> cũng trả rỗng. Bắt buộc "Precise".
 *  3. App nhắm API 29 trở lên gọi getAllCellInfo() CHỈ nhận dữ liệu cache; muốn số liệu
 *     tươi phải gọi requestCellInfoUpdate() (MainActivity làm việc này theo chu kỳ).
 *  4. Modem giới hạn ~2000 ms/lần hỏi -> chu kỳ đo đặt 3 giây, hỏi nhanh hơn chỉ tốn pin.
 *  5. 5G NSA (phổ biến ở Việt Nam): rất nhiều máy KHÔNG đưa CellInfoNr vào getAllCellInfo(),
 *     chỉ thấy CellInfoLte của ô neo. Vì vậy phải GỘP HAI NGUỒN — getAllCellInfo() lấy
 *     định danh ô, getSignalStrength() lấy cường độ (kể cả phần NR trong chế độ NSA).
 *  6. Băng thông/band chính xác nằm ở PhysicalChannelConfig, cần quyền cấp hệ thống
 *     READ_PRECISE_PHONE_STATE mà app thường không có -> chấp nhận các trường này có thể trống.
 */
object RadioReader {

    private const val NA = CellInfo.UNAVAILABLE

    private fun Int.orNull(): Int? = if (this == NA || this == Int.MAX_VALUE) null else this
    private fun Long.orNull(): Long? = if (this == CellInfo.UNAVAILABLE_LONG || this == Long.MAX_VALUE) null else this

    fun hasFineLocation(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    fun isLocationEnabled(ctx: Context): Boolean {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return false
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) lm.isLocationEnabled
        else lm.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
             lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    /** Lý do không đọc được (null = mọi thứ sẵn sàng). Trả về câu tiếng Việt cho người dùng cuối. */
    fun blockingReason(ctx: Context): String? = when {
        !hasFineLocation(ctx) ->
            "Chưa được cấp quyền Vị trí chính xác. Android bắt buộc quyền này mới cho đọc thông tin ô phục vụ. " +
            "Vào Cài đặt > Ứng dụng > MobiFone Đo Sóng > Quyền > Vị trí > chọn \"Cho phép khi dùng ứng dụng\" và bật \"Sử dụng vị trí chính xác\"."
        !isLocationEnabled(ctx) ->
            "Công tắc Định vị của máy đang TẮT. Khi tắt, hệ thống trả về danh sách ô rỗng mà không báo lỗi. Hãy bật Định vị rồi đo lại."
        else -> null
    }

    /**
     * Đọc một lần. [cached] là danh sách CellInfo mới nhất nhận được từ requestCellInfoUpdate()
     * (nếu có); nếu null thì tự lấy bằng getAllCellInfo().
     */
    fun read(ctx: Context, cached: List<CellInfo>?): JSONObject {
        val out = JSONObject()
        val reason = blockingReason(ctx)
        if (reason != null) return out.put("ok", false).put("canhBao", reason)

        val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
            ?: return out.put("ok", false).put("canhBao", "Máy không có phần cứng di động.")

        val cells: List<CellInfo> = try {
            cached ?: (tm.allCellInfo ?: emptyList())
        } catch (e: SecurityException) {
            return out.put("ok", false).put("canhBao", "Thiếu quyền đọc thông tin mạng: ${e.message}")
        } catch (e: Exception) {
            return out.put("ok", false).put("canhBao", "Lỗi đọc thông tin ô: ${e.message}")
        }

        // ---- Bẫy 5: cường độ lấy riêng từ getSignalStrength() (không cần quyền, và có cả phần NR khi chạy NSA)
        val ss: SignalStrength? =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) try { tm.signalStrength } catch (e: Exception) { null } else null
        val ssLte = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
            ss?.let { lteStrengthOf(it) } else null
        // Lớp CellSignalStrengthNr chỉ có từ Android 10; gọi qua hàm riêng để máy Android 8/9
        // không phải nạp lớp không tồn tại (tránh NoClassDefFoundError khi kiểm tra kiểu).
        val ssNr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            ss?.let { nrStrengthOf(it) } else null

        // Ô đang phục vụ = ô có isRegistered() = true; nếu modem không đánh dấu thì lấy phần tử đầu.
        val serving = cells.firstOrNull { it.isRegistered } ?: cells.firstOrNull()

        if (serving == null && ssNr == null && ssLte == null) {
            return out.put("ok", false).put(
                "canhBao",
                "Không nhận được thông tin ô nào từ modem. Thường do máy đang ở chế độ tiết kiệm pin, " +
                "vừa bật lại sóng, hoặc dòng máy này hạn chế cung cấp dữ liệu ô cho ứng dụng."
            )
        }

        out.put("ok", true)
        out.put("thoiDiemMs", System.currentTimeMillis())
        out.put("nhaMang", tm.networkOperatorName ?: JSONObject.NULL)

        var congNghe = "Không rõ"
        // 5G SA: xử lý trước và tách riêng vì lớp CellInfoNr chỉ tồn tại từ Android 10
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && isNrCell(serving)) {
            congNghe = fillNrServing(out, serving!!)
        } else when (serving) {
            is CellInfoLte -> {
                val id = serving.cellIdentity
                val sig = serving.cellSignalStrength
                congNghe = "4G LTE"
                out.put("cellId", id.ci.orNull() ?: JSONObject.NULL)
                out.put("pci", id.pci.orNull() ?: JSONObject.NULL)
                out.put("tac", id.tac.orNull() ?: JSONObject.NULL)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) out.put("tanSo", id.earfcn.orNull() ?: JSONObject.NULL)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    out.put("mcc", id.mccString ?: JSONObject.NULL)
                    out.put("mnc", id.mncString ?: JSONObject.NULL)
                    out.put("bangThongKhz", id.bandwidth.orNull() ?: JSONObject.NULL)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val bands = id.bands
                    if (bands.isNotEmpty()) out.put("band", bands.joinToString("/") { "B$it" })
                }
                // Ưu tiên số từ getSignalStrength() vì cập nhật liên tục hơn CellInfo
                out.put("rsrp", (ssLte?.rsrp ?: sig.rsrp).orNull() ?: JSONObject.NULL)
                out.put("rsrq", (ssLte?.rsrq ?: sig.rsrq).orNull() ?: JSONObject.NULL)
                out.put("sinr", (ssLte?.rssnr ?: sig.rssnr).orNull() ?: JSONObject.NULL)
                out.put("timingAdvance", sig.timingAdvance.orNull() ?: JSONObject.NULL)
            }
            is CellInfoWcdma -> {
                val id = serving.cellIdentity
                val sig = serving.cellSignalStrength
                congNghe = "3G WCDMA"
                out.put("cellId", id.cid.orNull() ?: JSONObject.NULL)
                out.put("pci", id.psc.orNull() ?: JSONObject.NULL)
                out.put("tac", id.lac.orNull() ?: JSONObject.NULL)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) out.put("tanSo", id.uarfcn.orNull() ?: JSONObject.NULL)
                out.put("rsrp", sig.dbm)
            }
            is CellInfoGsm -> {
                val id = serving.cellIdentity
                congNghe = "2G GSM"
                out.put("cellId", id.cid.orNull() ?: JSONObject.NULL)
                out.put("tac", id.lac.orNull() ?: JSONObject.NULL)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) out.put("tanSo", id.arfcn.orNull() ?: JSONObject.NULL)
                out.put("rsrp", serving.cellSignalStrength.dbm)
            }
        }

        // ---- Bẫy 5 (tiếp): đang neo LTE nhưng modem có báo cường độ NR -> thực tế là 5G NSA
        val nrRsrp = ssNr?.ssRsrp?.orNull()
        if (serving is CellInfoLte && nrRsrp != null) {
            congNghe = "5G NSA (neo 4G)"
            out.put("nrRsrp", nrRsrp)
            out.put("nrRsrq", ssNr.ssRsrq.orNull() ?: JSONObject.NULL)
            out.put("nrSinr", ssNr.ssSinr.orNull() ?: JSONObject.NULL)
        }
        out.put("congNghe", congNghe)

        // ---- Ô lân cận: tuỳ modem, nhiều dòng máy (đặc biệt Samsung) chỉ trả ô phục vụ.
        val nb = JSONArray()
        cells.filter { it !== serving && !it.isRegistered }.take(8).forEach { c ->
            val o = JSONObject()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && isNrCell(c)) fillNrNeighbor(o, c)
            else when (c) {
                is CellInfoLte -> {
                    o.put("pci", c.cellIdentity.pci.orNull() ?: JSONObject.NULL)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
                        o.put("tanSo", c.cellIdentity.earfcn.orNull() ?: JSONObject.NULL)
                    o.put("rsrp", c.cellSignalStrength.rsrp.orNull() ?: JSONObject.NULL)
                    o.put("rsrq", c.cellSignalStrength.rsrq.orNull() ?: JSONObject.NULL)
                }
                is CellInfoWcdma -> {
                    o.put("pci", c.cellIdentity.psc.orNull() ?: JSONObject.NULL)
                    o.put("rsrp", c.cellSignalStrength.dbm)
                }
                is CellInfoGsm -> o.put("rsrp", c.cellSignalStrength.dbm)
                else -> {}
            }
            if (o.length() > 0) nb.put(o)
        }
        out.put("lanCan", nb)

        if (nb.length() == 0) {
            out.put("canhBao", "Máy này không cung cấp dữ liệu ô lân cận (thường gặp ở nhiều dòng Samsung từ Android 10 trở lên). Số liệu ô đang phục vụ vẫn chính xác.")
        }
        return out
    }

    // ---------- Các hàm chỉ chạy trên Android 10+ (tách riêng để máy cũ không nạp lớp NR) ----------

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun isNrCell(c: CellInfo?): Boolean = c is CellInfoNr

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun nrStrengthOf(ss: SignalStrength): CellSignalStrengthNr? =
        ss.getCellSignalStrengths(CellSignalStrengthNr::class.java).firstOrNull()

    @RequiresApi(Build.VERSION_CODES.P)
    private fun lteStrengthOf(ss: SignalStrength): CellSignalStrengthLte? =
        ss.getCellSignalStrengths(CellSignalStrengthLte::class.java).firstOrNull()

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun fillNrServing(out: JSONObject, cell: CellInfo): String {
        val nr = cell as CellInfoNr
        val id = nr.cellIdentity as CellIdentityNr
        val sig = nr.cellSignalStrength as CellSignalStrengthNr
        out.put("cellId", id.nci.orNull() ?: JSONObject.NULL)
        out.put("pci", id.pci.orNull() ?: JSONObject.NULL)
        out.put("tac", id.tac.orNull() ?: JSONObject.NULL)
        out.put("tanSo", id.nrarfcn.orNull() ?: JSONObject.NULL)
        out.put("mcc", id.mccString ?: JSONObject.NULL)
        out.put("mnc", id.mncString ?: JSONObject.NULL)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && id.bands.isNotEmpty())
            out.put("band", id.bands.joinToString("/") { "n$it" })
        out.put("rsrp", sig.ssRsrp.orNull() ?: JSONObject.NULL)
        out.put("rsrq", sig.ssRsrq.orNull() ?: JSONObject.NULL)
        out.put("sinr", sig.ssSinr.orNull() ?: JSONObject.NULL)
        return "5G NR (SA)"
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun fillNrNeighbor(o: JSONObject, cell: CellInfo) {
        val nr = cell as CellInfoNr
        val id = nr.cellIdentity as CellIdentityNr
        val sig = nr.cellSignalStrength as CellSignalStrengthNr
        o.put("pci", id.pci.orNull() ?: JSONObject.NULL)
        o.put("tanSo", id.nrarfcn.orNull() ?: JSONObject.NULL)
        o.put("rsrp", sig.ssRsrp.orNull() ?: JSONObject.NULL)
        o.put("rsrq", sig.ssRsrq.orNull() ?: JSONObject.NULL)
    }
}
